import os
import random
from flask import render_template, url_for, request, redirect, flash, session
from Chatbot import app, db
from Chatbot.forms import RegistrationForm
from flask_login import login_user, current_user, logout_user, login_required

@app.route("/")


@app.route("/chatbot", methods=['GET', 'POST'])

def register():
    form = RegistrationForm()
    displayed = anything_else()
    callback = ""
    
    if form.validate_on_submit():
        text = form.username
        parsed = parse(text)
        displayed = first_question(parsed)
        callback = parsed
    return render_template('chatbot.html', title='Chatbot', form=form, displayed=displayed, callback=callback)



def parse(text):
    inputted = str(text)
    parsed_one = inputted[65:]
    parsed = parsed_one[:-2]
    return parsed        

def anything_else():
    
    return 'What would you like to ask?'

def first_question(question_f):
    
    if (question_f == 'What is my timetable for tomorrow?'):
        return ("""Your time table is \n ========= ======================================= 
   Time                    Subject                 
 ========= ======================================= 
  10:00am   CM2106 - Enhancing Your Employability  
  12:10pm   CM2305 - Group Project                 
  1:10pm    CM2104 - Computational Mathematics     
  3:10pm    CM2307 - Object Orientation            
 ========= =======================================""")
#        first_question()
    elif (question_f == 'What are the football scores?'):
        return ("""The scores are \n ================= ==== === === === ===== ===== == 
       Team         P    W   D   L   GD    Pts     
 ================= ==== === === === ===== ===== == 
  Bristol 1st       10   6   3   1    16    21     
  Bournemouth 1st   10   5   4   1    10    19     
  Bath 2nd          10   4   3   3    -2    15     
  Southampton 1st   10   4   2   4    -2    14     
  Cardiff 1st       10   1   3   6   -12     6     
  Cardiff Met 2nd   10   1   3   6   -10     6     
 ================= ==== === === === ===== ===== ==""")
 #       first_question()
    else:
        return ("I'm sorry I cannot answer that")
 #       first_question()
















