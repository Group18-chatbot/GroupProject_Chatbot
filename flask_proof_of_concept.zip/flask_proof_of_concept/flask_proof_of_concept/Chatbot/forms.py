from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField
from wtforms.validators import DataRequired, Length, EqualTo, ValidationError, Regexp

class RegistrationForm(FlaskForm):
    username = StringField('', validators=[DataRequired()])
    submit = SubmitField('Enter')

def validate_username(self, username):
    user = User.query.filter_by(username=username.data).first()
    if user:
        raise ValidationError('Username already exists. \
                                Please choose a different one.')

