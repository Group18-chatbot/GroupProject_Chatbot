from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

app = Flask(__name__)
app.config['SECRET_KEY'] = '3920004f6b48b5af1e077677b5b76894dc819819dee4d85e'

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://c1842623:FrankieBoyle@csmysql.cs.cf.ac.uk:3306/c1842623'
db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)

from Chatbot import routes

